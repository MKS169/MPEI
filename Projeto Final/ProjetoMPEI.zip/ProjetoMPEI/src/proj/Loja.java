package proj;

import java.util.HashMap;
import java.util.Map;

public class Loja implements LojaInterface{
	private String nomeLoja;
	private Map<String, Integer> produtos;
	
	public Loja(String nomeLoja, String listaProdutos) {
		this.nomeLoja = nomeLoja;
		produtos = new HashMap<>();
		String [] aux = listaProdutos.split(", ");
		for (String elem: aux) {
			produtos.put(elem.split(": ")[0], Integer.parseInt(elem.split(": ")[1]));
			// elem.split(": ")[0] --> Nome do produto (chave)
			// elem.split(": ")[1] --> Quantidade do produto (valor)	
		}
	}

	@Override
	public boolean addProduto(String produto, int quantidade) {
		// falta fazer coisas!
		
		produtos.put(produto, quantidade);
		return false;
	}

	@Override
	public boolean removeProduto(String produto) {
		// TODO Auto-generated method stub
		return false;
	}
	public String hashToString() {
		String s = "";
		for (String elem: produtos.keySet()) {
			s += elem + ": "+ produtos.get(elem) + ", ";
		}
		return s.substring(0, s.length() - 2); // para nao aparecer ", " no ultimo elemento
	}
	
	@Override
	public String toString() {
		return nomeLoja + "\t" + hashToString();
	}
}
