package proj;

public class Supermercado {

}
