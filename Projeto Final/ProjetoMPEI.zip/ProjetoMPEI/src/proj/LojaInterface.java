package proj;

public interface LojaInterface {
	public boolean addProduto(String produto, int quantidade);
	public boolean removeProduto(String produto);
}
